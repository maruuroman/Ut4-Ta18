import { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { AuthProvider, useAuth } from './Components/AuthContext';
import ProtectedRoute from './Components/ProtectedRoute';
import Home from './Components/Home';
import Dashboard from './Components/Dashboard';


function App() {
  const [count, setCount] = useState(0)

  return (
    <AuthProvider>
      <Router>
      <nav>
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/dashboard">Dashboard</Link> {/* Ruta protegida */}
            </li>
          </ul>
        </nav>

        <Routes>
          {/* Ruta pública */}
          <Route path="/" element={<Home />} />
          
          {/* Ruta protegida */}
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <Dashboard />
              </ProtectedRoute>
            }
          />
        </Routes>
      </Router>
    </AuthProvider>
  )
}

export default App;
