import { useAuth } from "./AuthContext";

const Home = () => {
  const { isAuthenticated, login, logout } = useAuth();
  return (
    <div>
      <h1>Home Page</h1>
      <p>{isAuthenticated ? "Estás autenticado" : "No estás autenticado"}</p>
      {!isAuthenticated ? (
        <button onClick={login}>Iniciar Sesión</button>
      ) : (
        <button onClick={logout}>Cerrar Sesión</button>
      )}
    </div>
  );
};

export default Home;
