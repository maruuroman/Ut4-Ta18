const Dashboard = () => {
  return (
    <div>
      <h2>Dashboard (Protegido)</h2>
      <p>Solo los usuarios autenticados pueden ver esto.</p>
    </div>
  );
};

export default Dashboard;
